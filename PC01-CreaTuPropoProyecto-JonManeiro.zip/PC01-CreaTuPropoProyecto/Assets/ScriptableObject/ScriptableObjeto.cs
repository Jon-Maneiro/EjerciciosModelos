using UnityEngine;

[CreateAssetMenu(fileName = "Data", menuName = "ScriptableObjects/SpawnObjetillo", order = 1)]
public class ScriptableObjeto : ScriptableObject
{

    public int veces;

}
